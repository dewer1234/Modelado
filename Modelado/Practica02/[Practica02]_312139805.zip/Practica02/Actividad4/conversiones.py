
def calculaCelsius(fahrenheit):
	celsius = (fahrenheit-32)/1.8
	return celsius

def calculaFahrenheit(celsius):
	fahrenheit = (celsius*1.8)+32
	return fahrenheit


