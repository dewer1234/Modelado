Brandon Padilla Ruiz

Observaciones: proyecto2.py es la parte del servidor y proyecto3.py es la parte del cliente