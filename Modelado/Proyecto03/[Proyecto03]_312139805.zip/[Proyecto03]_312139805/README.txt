
Brandon Padilla Ruiz
312139805
brandon.padilla.r@ciencias.unam.mx


NOTA:
Para correr el proyecto primero se compila el archivo Login.java, luego se corre UsoCarrito
por ejemplo:

-javac Login.java
-java UsoCarrito

Para entrar como administrador:
-admin
-pass

para entrar como usuario:
Yo agregue uno que es:
-user5
-password 

o bien se puede entrar a la interfaz del administrador y crear un nuevo usuario.
