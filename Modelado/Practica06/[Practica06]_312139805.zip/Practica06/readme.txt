Practica 6

Brandon Padilla Ruiz
312139805

El programa se corre en python 3, las entradas van tal cual como lo dice la especificacion del problema, por ejemplo 2 1 ó 5 7, para cerrar el programa ponemos el 1 1, que es el caso que no procesa nada.
