Practica 7

Brandon Padilla Ruiz
312139805
brandon.padilla.r@ciencias.unam.mx

La practica se puede abrir como proyecto de eclipse o bien juntar todos los archivos en un mismo directorio ya que se si se corre en la terminal de ubuntu no corre el programa, tuve problemas en esa parte de los directorios, en el controlador viene el main de la practica.