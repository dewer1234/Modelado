<html>
<head>
	<title>Restaurante</title>
	<meta charset="utf-8">
	<style type="text/css">
		body {

			background-image: url('itachi.jpg');
			background-size: 100% 100%;
			background-repeat: no-repeat;
		}

		#contenido {
			text-align: center;
			background: rgba(0,0,0,0.4);
			color: white;

		}


		#listado {
			margin-left: 20px;
			color: white;


		}
		

		#bienvenida {
			background-color: Maroon;
			border-radius: 30px 30px 30px 30px;
			font-size: 30;
			color: Black;
		}

		#opcion1{
			background-color: Maroon;
			border-radius: 30px 30px 30px 30px;
			font-size:25;


		}

		#opcion2{
			background-color: Maroon;
			border-radius: 30px 30px 30px 30px;
			font-size:25;


		}

		#opcion3{
			background-color: Maroon;
			border-radius: 30px 30px 30px 30px;
			font-size:25;


		}

		#opcion4{
			background-color: Maroon;
			border-radius: 30px 30px 30px 30px;
			font-size:25;


		}

		#pie {

			background: rgba(0,0,0,0.4);
			padding-top: 10px;
			padding-bottom: 30px;
			margin-top: -2px;
		}

		#tel{
			color: white;
		}



	</style>
</head>
<body>



<div id="contenido"> 
<div id="bienvenida">
	ANIME Y SERIES
</div>



<table id="listado">
	<tr>
		<td><img src="shippuden.jpg" width="150" height="200" /></td>
		<td><p> Naruto, un aprendiz de ninja de la Aldea Oculta de Konoha es un chico travieso que desea llegar a ser el Hokage de la aldea para demostrar a todos lo que vale. Lo que descubre al inicio de la historia es que la gente le mira con desconfianza porque en su interior está encerrado el demonio Kyubi que una vez destruyó la aldea, y que el anterior líder de la misma tuvo que encerrar en su cuerpo siendo aún muy pequeño, a coste de su vida. Aunque sus compañeros no saben esto, tampoco le aprecian porque es mal estudiante y siempre está haciendo bromas. Sin embargo, la forma de actuar y la determinación de Naruto demuestran a los demás que puede llegar muy lejos, y el recelo de los otros chicos se va disipando. Naruto y sus compañeros Sakura y Sasuke, junto a su maestro Kakashi tendrán que enfrentarse a una serie de combates y misiones a lo largo de la historia que les permitirán mejorar y crecer. Naruto se vera enfrentado a sus principales enemigos Akatsuki, Itachi y Kisame.</p></td>
		<td>
			
		</td>
		<td>
			<div id="opcion1">
			<a href="https://http://www.animeyt.tv/naruto-shippuden-audio-latino" target="_blank" >
				VER AHORA
			</div>
		</td>
	</tr>
	<tr>
		<td><img src="onepiece.jpg" width="150" height="200" /></td>
		<td> <p> Gol D. Roger, un hombre conocido como el Rey de los Piratas. Poco antes de su muerte, Roger hace mención a su gran tesoro legendario, el "One Piece", y a que puede ser tomado por todo aquél que lo desee. Esto marca el inicio de una era conocida como la Gran Era Pirata . Como resultado, un sin número de piratas zarparon hacia Grand Line con el objetivo de encontrarlo. Veintitantos años después de la muerte de Roger, un joven llamado Monkey D. Luffy, inspirado por la admiración que desde su infancia le tiene al poderoso pirata Shanks "el Pelirrojo" ,comienza su aventura desde su hogar en el East Blue para encontrar el One Piece y autoproclamarse como el nuevo Rey de los Piratas. Con el fin de crear y convertirse en el capitán de una tripulación propia, el muchacho funda la banda de los Sombreros de Paja</p></td>
		<td>
			
		</td>
		<td>
			<div id="opcion2">
			<a href="http://www.animeyt.tv/one-piece" target="_blank" >
				VER AHORA
			</div>
		</td>
	</tr>
	<tr>
		<td><img src="yugioh.jpg" width="150" height="200" /></td>
		<td> <p>Yūgi Mutō, un estudiante normal de secundaria, tenía como única amiga a Anzu. Yūgi había recibido por parte de su abuelo Sugoroku Mutō un antiguo artefacto egipcio conocido como el Rompecabezas del Milenio/Puzzle Milenario, uno de los siete Objetos Milenarios que había encontrado en una de sus expediciones arqueológicas. El Rompecabezas se encontraba dentro de una caja de oro y en múltiples piezas.Después de ocho largos años, a punto de completar tan difícil rompecabezas, lee una pequeña inscripción que poseía el mismo, la cual decía que quien completara ese rompecabezas se le podía conceder un deseo. Yūgi desea "tener amigos", pero a pocos instantes de colocarla, Jōnouchi y Hiroto roban la pieza.La historia continuará mientras que Yūgi y sus amigos se enfrentan a varios contrincantes,para tratar de encontrar las cartas de los Dioses Egipcios, ya que por medio de estas se podrán recuperar los recuerdos perdidos del faraón Atem (la verdadera identidad de Yami) a través de los Duelos de Monstruos que se reflejan en los Juegos de las Sombras.</p></td>
		<td>
			
		</td>
		<td>
			<div id="opcion3">
			<a href="http://www.animeyt.tv/yu-gi-oh" target="_blank" >
				VER AHORA
			</div>
		</td>
	</tr>
	<tr>
		<td><img src="pokemon.jpg" width="150" height="200" /></td>
		<td><p> ¡La aventura de Ash y Pikachu en la región Kalos llega a su clímax en Pokémon: La Serie XYZ! Ahora que le falta sólo una medalla de Gimnasio para poder entrar a la Liga Kalos, Ash persigue su sueño de convertirse en un Maestro Pokémon con determinación. Serena también está un paso más cerca de alcanzar sus sueños, ahora que su camino en La Exhibición/El Gran Espectáculo Pokémon se aproxima cada vez más a la competencia por la corona de la Reina de Kalos. Bonnie/clem tiene un nuevo amigo a quien cuidar con el adorable aunque misterioso Blandito/Blandín, pero pronto queda claro que hay fuerzas siniestras en movimiento que podrían separarlos. ¿Conseguirá el sombrío Equipo/Team Flare cumplir su deseo, o lograrán nuestros héroes proteger a Blandito/Blandín, y a toda la Región Kalos, de sus ardientes ambiciones?.</p></td>
		<td>
			
		</td>
		<td>
			<div id="opcion4">
			<a href="http://www.animeyt.tv/pokemon-xy-z" target="_blank" >
				VER AHORA
			</div>
		</td>
	</tr>
	



</table>

</div>

<div id="pie">

<div id="tel">Otros enlaces:</div>

<ul>
<li type="circle"><a href="http://tvpelis.net/" target="_blank" > http://tvpelis.net/</li>
<li type="circle"><a href="http://www.animeyt.tv/" target="_blank" >http://www.animeyt.tv/ </li>
<li type="circle"><a href="https://www.crunchyroll.com/" target="_blank" >https://www.crunchyroll.com/</li>
</ul>
</div>

</body>
</html>




